package com.example.examen1_jrlc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
